package com.example.pdf;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.EmptyStackException;
import java.util.Stack;

public class MainActivity extends AppCompatActivity {

    String str="";
    private TextView result;
    private TextView clear;
    private TextView del;
    private TextView divide;
    private TextView nine;
    private TextView eight;
    private TextView seven;
    private TextView six;
    private TextView five;
    private TextView four;
    private TextView three;
    private TextView two;
    private TextView one;
    private TextView zero;
    private TextView point;
    private TextView plus;
    private TextView minus;
    private TextView multiplication;
    private TextView equal;
    private TextView nag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        findViewByIds();
        setListeners();
    }

    private void findViewByIds(){
        result=findViewById(R.id.result);
        clear=findViewById(R.id.clear);
        divide=findViewById(R.id.divide);
        del=findViewById(R.id.del);
        one=findViewById(R.id.one);
        two=findViewById(R.id.two);
        three=findViewById(R.id.three);
        four=findViewById(R.id.four);
        five=findViewById(R.id.five);
        six=findViewById(R.id.six);
        seven=findViewById(R.id.seven);
        eight=findViewById(R.id.eight);
        nine=findViewById(R.id.nine);
        plus=findViewById(R.id.plus);
        minus=findViewById(R.id.minus);
        multiplication=findViewById(R.id.multiplication);
        equal=findViewById(R.id.equal);
        zero=findViewById(R.id.zero);
        point=findViewById(R.id.point);
        nag=findViewById(R.id.nag);
    }

    private void setListeners(){
        clear.setOnClickListener(btnClick);
        divide.setOnClickListener(btnClick);
        del.setOnClickListener(btnClick);
        one.setOnClickListener(btnClick);
        two.setOnClickListener(btnClick);
        three.setOnClickListener(btnClick);
        four.setOnClickListener(btnClick);
        five.setOnClickListener(btnClick);
        six.setOnClickListener(btnClick);
        seven.setOnClickListener(btnClick);
        eight.setOnClickListener(btnClick);
        nine.setOnClickListener(btnClick);
        plus.setOnClickListener(btnClick);
        minus.setOnClickListener(btnClick);
        multiplication.setOnClickListener(btnClick);
        equal.setOnClickListener(btnClick);
        zero.setOnClickListener(btnClick);
        point.setOnClickListener(btnClick);
        nag.setOnClickListener(btnClick);
    }
    public static double calculate(String expression) {
        Stack<Double> numbers = new Stack<>();
        Stack<Character> operators = new Stack<>();

        StringBuilder numberBuilder = new StringBuilder();
        boolean lastWasOperator = true; // 用於判斷負號

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (Character.isDigit(c) || c == '.') {
                numberBuilder.append(c);
                lastWasOperator = false;
            } else if (isOperator(c)) {
                if (c == '-' && lastWasOperator) {
                    // 處理負數
                    numberBuilder.append(c);
                } else {
                    if (numberBuilder.length() > 0) {
                        numbers.push(Double.parseDouble(numberBuilder.toString()));
                        numberBuilder.setLength(0);
                    }

                    while (!operators.isEmpty() && hasPrecedence(c, operators.peek())) {
                        numbers.push(applyOperation(operators.pop(), numbers.pop(), numbers.pop()));
                    }
                    operators.push(c);
                    lastWasOperator = true;
                }
            }
        }

        if (numberBuilder.length() > 0) {
            numbers.push(Double.parseDouble(numberBuilder.toString()));
        }

        while (!operators.isEmpty()) {
            numbers.push(applyOperation(operators.pop(), numbers.pop(), numbers.pop()));
        }

        return numbers.pop();
    }

    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    private static boolean hasPrecedence(char op1, char op2) {
        return (op1 != '*' && op1 != '/') || (op2 != '+' && op2 != '-');
    }

    private static double applyOperation(char operator, double b, double a) {
        switch (operator) {
            case '+': return a + b;
            case '-': return a - b;
            case '*': return a * b;
            case '/':
                if (b == 0) throw new ArithmeticException("Division by zero");
                return a / b;
        }
        return 0;
    }
    private View.OnClickListener btnClick=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(str=="error"){
                str="";
            }
            int id = v.getId();
            if (id == R.id.clear) {
                str = "";
            } else if (id == R.id.one) {
                str += "1";
            } else if (id == R.id.two) {
                str += "2";
            } else if (id == R.id.three) {
                str += "3";
            } else if (id == R.id.four) {
                str += "4";
            } else if (id == R.id.five) {
                str += "5";
            } else if (id == R.id.six) {
                str += "6";
            } else if (id == R.id.seven) {
                str += "7";
            } else if (id == R.id.eight) {
                str += "8";
            } else if (id == R.id.nine) {
                str += "9";
            } else if (id == R.id.zero) {
                str += "0";
            } else if (id==R.id.del){
                if(!str.isEmpty())
                    str=str.substring(0,str.length()-1);
            } else if (id==R.id.nag) {
                if(str.length()>0&&str.charAt(0)=='-')
                    str=str.substring(1,str.length());
                else
                    str='-'+str;
            } else if (id==R.id.point) {
                if(str.indexOf('.')==-1){
                    str+='.';
                }
            } else if (id==R.id.plus) {
                str+='+';
            } else if (id==R.id.minus) {
                str+='-';
            } else if (id==R.id.multiplication) {
                str+='*';
            } else if (id==R.id.divide) {
                str+='/';
            } else if (id==R.id.equal) {
                try{
                    double ans=calculate(str);
                    if(ans%1!=0)
                        str=""+ans;
                    else
                        str=String.format("%.0f",ans);
                }catch (EmptyStackException e){
                    str="error";
                }catch (NumberFormatException e){
                    str="error";
                }catch (ArithmeticException e){
                    str="error";
                }

            }
            result.setText(str);
        }
    };
}